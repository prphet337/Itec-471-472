package com.example.rateem;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class MainActivity extends Activity implements OnClickListener {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		// code from http://stackoverflow.com/questions/14207392/android-button-click-go-to-another-xml-page
		// Button mBtn1 = (Button) findViewById(R.id.mBtn1);
		// mBtn1.setOnClickListener(this);
		// end code from http://stackoverflow.com/questions/14207392/android-button-click-go-to-another-xml-page
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}
	
	public void onClick(View v) {
		Intent i = new Intent(MainActivity.this, Create.class);
		Button create_New = (Button) findViewById(R.id.button1);
		create_New.setOnClickListener(this);
		startActivity(i);
	}
	
	

}
